#define COURSE_NAME "15213-f11"

#define LAB "tshlab"
#define SERVER_NAME "unofficial.fish.ics.cs.cmu.edu"
#define SERVER_PORT 80
#define AUTOGRADE_TIMEOUT 0
